import pymongo


#gets you the handler on the mongo client
client = pymongo.MongoClient()
#choose the data base
db = client.Surveys
#choose the collection
collection = db.usersurveystemp
#example code
def InsertRecords(username,email,color,food,vacation,valuebefore,valueafter,comment,focus):
	collection.insert({"username" : username, "email" : email, "Color" : color, "food" : food, "vacation" : vacation, "fe-before" : valuebefore, "fe-after" : valueafter, "comment" : comment, "focus" : focus})


def display():
	return collection
