from app import myapp,model
from flask import request, render_template, session, redirect, url_for, escape
import os

myapp.secret_key = os.urandom(24)

@myapp.route('/')
@myapp.route('/index')
def index():
	username = ''
	if 'username' in session:
		username = escape(session['username'])
		return render_template('survey.html', name=username)
	else:
		return render_template('login.html')

@myapp.route('/login', methods=['GET', 'POST'])
def login():
	if request.method=='POST':
		session['username'] = request.form['username']
		session['email'] = request.form['email']
		return redirect(url_for('index'))

@myapp.route('/logout')
def logout():
	session.pop('username', None)
	session.pop('email', None)
	return redirect(url_for('index'))

@myapp.route('/aggregate')
def newpage():
	if 'username' in session:
		username = escape(session['username'])
	else:
		username = 'Guest'
	score_before = 0.0
	score_after = 0.0
	count = 0
	items = model.display()
	before_count = items.find({}, {'fe-before': 1, '_id': 0}).count()
	after_count = items.find({}, {'fe-after': 1, '_id': 0}).count()
	total_responses = items.find({}, {'username': 1, '_id': 0}).count()
	# print before_count
	# print after_count
	for data in items.find({}, {'fe-before': 1, 'fe-after': 1, '_id': 0}):
		score_before = score_before + float(data.get('fe-before'))
		score_after = score_after + float(data.get('fe-after'))
	# print score_after
	# print score_before
	avg_score_before = score_before/before_count
	avg_score_after = score_after/after_count
	print avg_score_after
	print avg_score_before

	return render_template('aggregate.html',name=username, score_before=avg_score_before, score_after=avg_score_after, count=total_responses)

@myapp.route('/submit-survey', methods=['GET', 'POST'])
def submitSurvey():
	username = ''
	email = ''
	if 'username' in session:
		username = escape(session['username'])
		email = escape(session['email'])
		surveyResponse = {}
		surveyResponse['color'] = request.form.get('color')
		surveyResponse['food'] = request.form.get('food')
		surveyResponse['vacation'] = request.form.get('vacation')
		surveyResponse['fe-before'] = request.form.get('feBefore')
		surveyResponse['fe-after'] = request.form.get('feAfter')
		surveyResponse['comments'] = request.form.get('comments')
		surveyResponse['focus'] = request.form.get('focus')
		#insert code here to send surveyresponse into your mongoDB
		model.InsertRecords(username, email, surveyResponse['color'],surveyResponse['food'],surveyResponse['vacation'],surveyResponse['fe-before'],surveyResponse['fe-after'], surveyResponse['comments'], surveyResponse['focus'])

		return render_template('results.html', name=username, email=email, surveyResponse=surveyResponse)
	else:
		return render_template('login.html')

@myapp.errorhandler(404)
def page_not_found(error):
	return render_template('page_not_found.html'), 404
